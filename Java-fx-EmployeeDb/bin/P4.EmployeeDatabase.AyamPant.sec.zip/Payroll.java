import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import java.text.SimpleDateFormat;

/**
 * 
 * @author ayamp
 * @version 03/11/2023 This class creates a file employee data that includes the
 *          boss information on startup and then allow user to add employees as
 *          they go
 */
public class Payroll {

	private static ArrayList<Employee> employeeList;
	private static String menu = "Payroll Menu\n\t" + "1. Log In" + "\n\t" + "2. Enter employees\n\t"
			+ "3. List Employees \n\t" + "4. Terminate an Employee\n\t" + "5. Pay Employees\n\t" + "0. Exit System";
	private static Employee currentUser;
	private static Scanner inputSc = new Scanner(System.in);
	public static final String fileName = "employeeList.txt";

	/**
	 * Payroll constructor when the first this program is run, it will create a new
	 * employee boss as the file do not exist
	 */
	public Payroll() {
		employeeList = new ArrayList<>();
		currentUser = null;
		try {
			Scanner fileSc = new Scanner(new File(fileName));
			while (fileSc.hasNextLine()) {
				String line = fileSc.nextLine();
				String[] parts = line.split("\t");
				int id = Integer.parseInt(parts[0]);
				String loginName = parts[1];
				double salary = Double.parseDouble(parts[2]);
				String currDate = parts[3];
				String name = parts[4];
				Employee employee = new Employee(id, loginName, salary, name, currDate);
				employeeList.add(employee);
			}
			fileSc.close();

		} catch (FileNotFoundException e) {
			System.out.println(
					"Employee list file not found. \n Please enter information to add information of the Boss. \n");
			System.out.println("Enter Log on Name:");
			String loginName = inputSc.nextLine();
			System.out.println("Enter Name:");
			String name = inputSc.nextLine();
			System.out.println("Enter the Salary:");
			double salary = inputSc.nextDouble();
			Date curDate = new Date();
			Employee boss = new Employee(loginName, salary, name, convertDateToString(curDate));
			employeeList.add(boss);
			currentUser = boss;
		}

	}

	/**
	 * this method is used to display menu to the user
	 * This system doesn't not allow to do anything without logging in. 
	 * So user has to login first before accessing menu options.
	 */
	public static void displayMenu() {
		if(currentUser == null) {
			System.out.println("Please login before using the system.\n");
			login();
		}
		try {
			int choice = -1;
			do {
				System.out.println(Payroll.menu);
				System.out.println("Choose from the above options.");
				try {
					choice = inputSc.nextInt();
					if (choice < 0 || choice > 5) {
						String junk = inputSc.nextLine();
						System.out.printf("Bad input.:  %s %s\n", choice, junk);
					}
				} catch (Exception e) {
					String junk = inputSc.nextLine();
					System.out.printf("Input needs to be a number:  %s\n", junk);
				}
			} while (choice < 0 || choice > 5);

			switch (choice) {
			case 0:
				exitSystem();
				break;
			case 1:
				login();
				break;
			case 2:
				enterEmployee();
				break;
			case 3:
				listEmployees();
				break;
			case 4:
				terminateEmployee();
				break;
			case 5:
				payEmployee();
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * login method
	 */
	private static void login() {
		System.out.print("Enter your login name: ");
		String loginName = inputSc.next();
		boolean userFound = false;

		for (Employee employee : Payroll.employeeList) {
			if (employee.getLoginName().equals(loginName)) {
				currentUser = employee;
				System.out.println("Login Successfull!!!\n");
				System.out.println("Logged in as " + currentUser.getName() + ". \n");
				userFound = true;
			}
		}
		if (!userFound)
			System.out.println("User not found.\n");
		displayMenu();
	}

	/**
	 * Method to add new employeee
	 */
	private static void enterEmployee() {
		System.out.println("Please enter information to employee. \n");
		System.out.println("Enter Log on Name:");
		inputSc.nextLine();
		String loginName = inputSc.nextLine();
		System.out.println("Enter Name:");
		String name = inputSc.nextLine();
		System.out.println("Enter the Salary:");
		double salary = inputSc.nextDouble();
		Date curDate = new Date();
		Employee newEmployee = new Employee(loginName, salary, name, convertDateToString(curDate));
		employeeList.add(newEmployee);
		System.out.print("New Employee Added!\n");
		displayMenu();
	}

	/**
	 * method to list employees
	 */
	private static void listEmployees() {
		System.out.print("List employees called!!\n");

	}

	/**
	 * method to terminate employee
	 */
	private static void terminateEmployee() {
		System.out.print("Terminate Employee called!!\n");

	}

	/**
	 * method to pay employee
	 */
	private static void payEmployee() {
		System.out.print("Pay Employee called!!\n");

	}

	/**
	 * method to exit system
	 */
	private static void exitSystem() {
		Payroll.writeEmployeeListtoFile(employeeList);
		System.out.print("Exiting program!");
		System.exit(0);
	}

	/**
	 * 
	 * @param listOfEmployee uses the list to write to a file
	 */
	private static void writeEmployeeListtoFile(ArrayList<Employee> listOfEmployee) {
		try {
			PrintWriter pw = new PrintWriter(new File(fileName));
			for (Employee employee : listOfEmployee) {
				pw.print(employee.toString());
			}
			pw.close();
		} catch (FileNotFoundException e) {
			System.out.println("File not found.");
		}
	}

	/**
	 * 
	 * @param date date to be converted
	 * @return string value of converted date to mm dd yyyy format
	 */
	private static String convertDateToString(Date date) {
		SimpleDateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
		String formattedDate = formatter.format(date);
		return formattedDate;
	}

}
